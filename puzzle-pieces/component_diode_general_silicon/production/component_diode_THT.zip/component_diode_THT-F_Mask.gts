G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*
G04 #@! TF.CreationDate,2026-10-09T09:14:51+02:00*
G04 #@! TF.ProjectId,component_diode_THT,636f6d70-6f6e-4656-9e74-5f64696f6465,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-10-09 09:14:51*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMOutline4P*
0 Free polygon, 4 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 4*
0 $1 to $8 corner X, Y*
0 $9 Rotation angle, in degrees counterclockwise*
0 create outline with 4 corners*
4,1,4,$1,$2,$3,$4,$5,$6,$7,$8,$1,$2,$9*%
G04 Aperture macros list end*
%ADD10C,3.000000*%
%ADD11C,2.000000*%
%ADD12Outline4P,-1.800000X-1.150000X1.800000X-0.550000X1.800000X0.550000X-1.800000X1.150000X0.000000*%
%ADD13Outline4P,-1.800000X-1.150000X1.800000X-0.550000X1.800000X0.550000X-1.800000X1.150000X180.000000*%
%ADD14C,1.700000*%
%ADD15O,1.700000X1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H3*
X-16000000Y16000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,D1*
X-5200000Y0D03*
X7500000Y0D03*
G04 #@! TD*
D10*
G04 #@! TO.C,H1*
X-16000000Y-16000000D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X16000000Y16000000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D2*
X-1900000Y-10000000D03*
D13*
X3900000Y-10000000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,J5*
X14412500Y1270000D03*
D15*
X14412500Y-1230000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,H2*
X16000000Y-16000000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,J1*
X-14412500Y-1270000D03*
D15*
X-14412500Y1230000D03*
G04 #@! TD*
M02*
