G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*
G04 #@! TF.CreationDate,2026-10-07T15:30:20+02:00*
G04 #@! TF.ProjectId,component_capacitor-polarized_ruggedized_replacable,636f6d70-6f6e-4656-9e74-5f6361706163,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-10-07 15:30:20*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X0.450000X0.800000X-0.450000X0.800000X-0.450000X-0.800000X0.450000X-0.800000X0*%
%ADD11RoundRect,0.250000X-1.500000X-0.650000X1.500000X-0.650000X1.500000X0.650000X-1.500000X0.650000X0*%
%ADD12C,3.000000*%
%ADD13R,1.200000X2.000000*%
%ADD14R,1.020000X2.400000*%
%ADD15C,1.700000*%
%ADD16O,1.700000X1.700000*%
%ADD17RoundRect,0.250000X0.400000X0.625000X-0.400000X0.625000X-0.400000X-0.625000X0.400000X-0.625000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,D2*
X3450000Y8000000D03*
X-950000Y8000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,D1*
X-3750000Y-12000000D03*
X1250000Y-12000000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H3*
X-16000000Y16000000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J2*
X-2540000Y1750000D03*
D14*
X-2540000Y-3950000D03*
X0Y1450000D03*
X0Y-3950000D03*
D13*
X2500000Y1750000D03*
D14*
X2540000Y-3950000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H1*
X-16000000Y-16000000D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X16000000Y16000000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,J5*
X14412500Y1270000D03*
D16*
X14412500Y-1230000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H2*
X16000000Y-16000000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,J1*
X-14412500Y-1270000D03*
D16*
X-14412500Y1230000D03*
G04 #@! TD*
D17*
G04 #@! TO.C,R1*
X2800000Y13000000D03*
X-300000Y13000000D03*
G04 #@! TD*
M02*
